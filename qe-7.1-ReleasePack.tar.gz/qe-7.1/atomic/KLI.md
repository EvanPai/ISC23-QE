# Notes in the implementation of the KLI aproximation

