rm -rf results
rm -f difference
rm -f ld1*
