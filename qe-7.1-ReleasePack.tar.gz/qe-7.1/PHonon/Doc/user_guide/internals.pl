# LaTeX2HTML 2019.2 (Released June 5, 2019)
# Associate internals original text with physical files.


$key = q/Sec:para/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

1;

