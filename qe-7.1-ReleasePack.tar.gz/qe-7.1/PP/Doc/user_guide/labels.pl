# LaTeX2HTML 2019.2 (Released June 5, 2019)
# Associate labels original text with physical files.


1;


# LaTeX2HTML 2019.2 (Released June 5, 2019)
# labels from external_latex_labels array.


$key = q/_/;
$external_latex_labels{$key} = q|<|; 
$noresave{$key} = "$nosave";

1;

